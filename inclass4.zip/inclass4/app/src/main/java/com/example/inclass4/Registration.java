package com.example.inclass4;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Registration#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Registration extends Fragment {
    TextView departmentSelection;
    TextView nameEntered;
    TextView emailEntered;
    TextView idEntered;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    static String registrationUpdate;
    static String name;
    static String email;
    static String id1;


    public Registration() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Registration.
     */
    // TODO: Rename and change types and number of parameters
    public static Registration newInstance(String param1, String param2) {
        Registration fragment = new Registration();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        MainActivity myActivity = (MainActivity) getActivity();
        registrationUpdate = myActivity.getMyData();
        name = myActivity.getName();
        email = myActivity.getEmail();
        id1 = myActivity.getID();
        Log.d("Lookover","Department From Registration Fragment: " + registrationUpdate);
        return inflater.inflate(R.layout.fragment_registration, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        departmentSelection = view.findViewById(R.id.departmentTextView1);
        nameEntered = view.findViewById(R.id.nameTextView);
        emailEntered = view.findViewById(R.id.emailTextView);
        idEntered = view.findViewById(R.id.IDtextView);
        departmentSelection.setText(registrationUpdate);
        nameEntered.setText(name);
        emailEntered.setText(email);
        idEntered.setText(id1);
        getActivity().findViewById(R.id.selectButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.relativeView2, new Department(), "Frag").addToBackStack(null).commit();
                Log.d("Send_Data","Got on here at least: ");
                name = nameEntered.getText().toString();
                Log.d("Send_Data","Got name to pass: " + name);
                email = emailEntered.getText().toString();
                Log.d("Send_Data","Got email to pass: " + email);
                id1 = idEntered.getText().toString();
                Log.d("Send_Data","Got name to ID: " + id1);
                dataInterface.sendNameData(nameEntered.getText().toString());
                dataInterface.sendEmail(emailEntered.getText().toString());
                dataInterface.sendID(idEntered.getText().toString());
                }
        });

        getActivity().findViewById(R.id.submitButton1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nameEntered.getText().toString().isEmpty() || emailEntered.getText().toString().isEmpty()
                    || idEntered.getText().toString().isEmpty()) {
                    Toast.makeText(getActivity(), "Enter All Text Fields", Toast.LENGTH_SHORT).show();
                } else if (departmentSelection.getText().toString().isEmpty() && nameEntered.getText().toString().isEmpty() == false
                        && idEntered.getText().toString().isEmpty() == false && emailEntered.getText().toString().isEmpty() == false) {
                        Toast.makeText(getActivity(),"Press Select Button To Make Department Changes",Toast.LENGTH_LONG).show();
                } else {
                    User user = new User (nameEntered.getText().toString(),emailEntered.getText().toString(),
                            Integer.valueOf(idEntered.getText().toString()),departmentSelection.getText().toString());
                    Log.d("User Created","\nUser Created\nUser Name: " + user.getName()
                    + "\nUser Email: " + user.getEmail() + "\nUser ID: " + user.getIdNumber() + "\nUser Department: " + user.getDepartment());
                    getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.relativeView2, new UserFragment(), "Frag").addToBackStack(null).commit();

                }
            }
        });
    }

    TextView textView;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if (context instanceof Registration.passingData) {
            dataInterface = (Registration.passingData) context;
        } else {
            throw new RuntimeException((context.toString()) + " Must implement listener");
        }
    }

    passingData dataInterface;

    public interface passingData  {
        void sendNameData (String name);
        void sendEmail (String email);
        void sendID (String id);
    }
}