package com.example.inclass4;

public class User {
    static String name;
    static String email;
    static int idNumber;
    static String department;

    public User () {

    }

    public User (String name, String email, int idNumber, String department) {
        this.name = name;
        this.email = email;
        this.idNumber = idNumber;
        this.department = department;
    }

    public String getEmail() {
        return email;
    }

    public int getIdNumber() {
        return idNumber;
    }

    public String getDepartment() {
        return department;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setIdNumber(int idNumber) {
        this.idNumber = idNumber;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
