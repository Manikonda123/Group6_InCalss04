package com.example.inclass4;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements Department.IListener, Registration.passingData {
    static String department = null;
    Registration registration;
    Bundle bundle;
    String name;
    String email;
    String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction().add(R.id.relativeView2, new FirstFragment(), "Frag").addToBackStack(null).commit();
    }

    @Override
    public void setDepartment(String department) {
        this.department = department;
        Log.d("Final","Department From Main Activity: " + this.department);
        Department department1 = (Department) getSupportFragmentManager().findFragmentByTag("Frag");
    }

    public String getMyData () {
        return this.department;
    }

    public String getName () {
        return this.name;
    }

    public String getEmail () {
        return this.email;
    }

    public String getID () {
        return this.id;
    }


    @Override
    public void sendNameData(String name) {
        this.name = name;
        Log.d("RegisterHoes","Name From Main Activity: " + this.name);
    }

    @Override
    public void sendEmail(String email) {
        this.email = email;
        Log.d("RegisterHoes","Email From Main Activity: " + this.email);
    }

    @Override
    public void sendID(String id) {
        this.id = id;
        Log.d("RegisterHoes","ID From Main Activity: " + this.id);
    }
}
